---
title: "Data on AnVIL"
date: "September 15, 2026"
site: bookdown::bookdown_site
documentclass: book
bibliography: book.bib
biblio-style: apalike
link-citations: yes
description: This book contains vignettes on how to upload, import, or access data within an AnVIL workspace.
favicon: assets/AnVIL_style/anvil_favicon.ico
---


# About this Book {-}

The chapters within this book contain hands-on activities to demonstrate how users can access and use data within an AnVIL workspace. Topics include bringing your own data from an HPC, finding data already hosted on AnVIL with tools like the Data Explorer, importing data from online data repositories like SRA, and getting access to protected data stored in places like dbGaP.

This book is part of a series of books for the Genomic Data Science Analysis, Visualization, and Informatics Lab-space (AnVIL) of the National Human Genome Research Institute (NHGRI). Learn more about AnVIL by visiting https://anvilproject.org or reading the [article in Cell Genomics](https://www.sciencedirect.com/science/article/pii/S2666979X21001063).

## Skills Level {-} 

::: {.notice}
_Genetics_

**Novice**: no genetics skills needed

_Programming skills_

**Novice**: no programming skills needed
:::

## AnVIL Collection {-}

Please check out our full collection of AnVIL and related resources: https://hutchdatascience.org/AnVIL_Collection/
